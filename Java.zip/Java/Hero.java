import java.util.*;
import java.lang.*;
import java.io.*;

interface Bike
{
void start();
void gearChange();
void run();
}
class Hero implements Bike
{
public void start()
{
System.out.println("Your Hero Bike Is Started");
}
public void gearChange()
{
System.out.println("Bro Change Your Gear First This is Not A Activa");
}
public void run()
{
System.out.println("Bro Now You Can Fly On the Sky");
}
public static void main(String[] args)
{
Hero b=new Hero();
b.start();
b.gearChange();
b.run();
;

for(int i=0;i<5;i++)
{
System.out.println(a);
}
}
}