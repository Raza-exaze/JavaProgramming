public class BubbleSort
{
public static void main(String args[])
{
int[] bubble={10,9,7,101,23,44,12,78,34,23};  
for(int bubb:bubble)
{
System.out.println(bubb);
}

for(int i=0;i<10;i++)
{
for(int j=0;i<10;j++)
{
if(bubble[i]<bubble[j])
{
int temp=bubble[i];
bubble[i]=bubble[j];
bubble[j]=temp;
}
}
}
System.out.println("Sorted Elements:");
for(int i=0;i<10;i++)
{
System.out.println(bubble[i]);
}
}
}