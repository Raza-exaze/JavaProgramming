public class ExampleSynchroMethod
{
public synchronized void method1()
{
try
{
System.out.println("Method One Position");
Thread.sleep(5000);
}
catch(Exception e)
{
System.out.println(e.getMessage());
}
finally
{
System.out.println("Finally Block Execute");
}
}
public synchronized void method2()
{
try
{
System.out.println("Method Second Started");
for(int i=0;i<10;i++)
{
System.out.println("Methods 2:"+i);
Thread.sleep(2000);
}
}
catch(Exception e)
{
System.out.println(e.getMessage());
}
finally
{
System.out.println("Method 2 Finally Block");
}
}
public static void main(String args[])
{
ExampleSynchroMethod e=new ExampleSynchroMethod();
e.method1();
e.method2();
}
}