class CopyConstructor
{
private double fprice;
private String fname;

CopyConstructor(double price,String name)
{
this.fprice=price;
this.fname=name;
}
CopyConstructor(CopyConstructor c)
{
fprice=c.fprice;
fname=c.fname;
}
double showPrice()
{
return fprice;
}
String showName()
{
return fname;
}
public static void main(String args[])
{
CopyConstructor cc=new CopyConstructor(200,"Khan");
System.out.println("Simple Contructor Return Value Of The Object:");
System.out.println("Price Of The Food:"+cc.fprice);
System.out.println("Buyer Name:"+cc.fname);

CopyConstructor c=new CopyConstructor(cc);
System.out.println("Copy Constructor Return Value Of the Parent Object:");
System.out.println("Price Of The Food:"+c.showPrice());
System.out.println("Buyer Name:"+c.showName());
}
}