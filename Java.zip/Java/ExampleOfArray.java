import java.util.*;

class ExampleOfArray 
{
    public static void main(String[] args) 
    {
        // List<String> al=new ArrayList<String>();
        // al.add("Java");
        // al.add("Python");
        
        // String[] name=new String[al.size()];
        // name=al.toArray(name);
        
        // for(String names : name)
        // {
        //     System.out.print(names);
        // }
        String[] name={"Java","Python","Ruby"};
        
        List<String> al=new ArrayList<String>(Arrays.asList(name));
        System.out.println(al);
        
        al.add("C");
        al.add("C#");
        
        System.out.println(al);
    }
}