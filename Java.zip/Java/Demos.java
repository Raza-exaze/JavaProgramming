class Demos
{
public Demos()
{
}
public static void main(String args[])
{
System.out.println("Hello Java Programmer");
Demos c=new Demos();
}
}