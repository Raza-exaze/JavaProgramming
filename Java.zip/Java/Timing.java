import java.time.*;


class Timing
{
public static void main(String args[])
{

ZonedDateTime zz=ZonedDateTime.now();

System.out.println("Date Of The Day");
System.out.println(zz.getMonth());
System.out.println(zz.getDayOfWeek());
System.out.println(zz.getDayOfMonth());
System.out.println(zz.getYear());

}
}


