import java.util.*;
import java.lang.*;

class ExampleDemo
{
public static void main(String args[])
{
Integer a[]={2,1,3,5,4,6};

ArrayList<Integer> al=new ArrayList<Integer>(Arrays.asList(a));
Collections.sort(al);

System.out.println(al);
}
}