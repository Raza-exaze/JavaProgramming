import java.util.Scanner;

public class LinearSearch
{
public static void main(String args[])
{
int[] a={1,3,4,5,6,7,8,9};

int item,flag=0;

Scanner scan=new Scanner(System.in);
System.out.println("Enter Your Number:");
item=scan.nextInt();

for(int i=0;i<a.length;i++)
{
if(a[i]==item)
{
flag=i+1;
break;
}
else
{
flag=0;
}
}
if(flag!=0)
{
System.out.println("Search Element Is Available Ever DataBase:"+flag);
}
else
{
System.out.println("Searching Element Is Not-Available Ever DataBase");
}
}
}