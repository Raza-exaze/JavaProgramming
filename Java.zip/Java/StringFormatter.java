public class StringFormatter
{
public static String reverseString(String str)
{
StringBuilder sb=new StringBuilder(str);
sb.reverse();
return sb.toString();
}
public static void main(String args[])
{
System.out.println("Correct Position of Words: Java Is A Programming Language");
System.out.println("Reverse Position of Words:"+StringFormatter.reverseString("Java Is A Programming Language"));
}
}
