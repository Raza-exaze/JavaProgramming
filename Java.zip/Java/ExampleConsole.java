import java.io.Console;

public class ExampleConsole
{
public static void main(String args[])
{
Console c=System.console();
System.out.println("Enter Your Name:");
String name=c.readLine();
System.out.println("Welcome:"+name);
}
}