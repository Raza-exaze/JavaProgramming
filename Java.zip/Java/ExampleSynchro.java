public class ExampleSynchro
{
public Object lock1=new Object();
public Object lock2=new Object();


public void method1()
{
synchronized(lock1)
{
try
{
System.out.println("Method One Is Called");
Thread.sleep(5000);
}
catch(Exception e)
{
System.out.println(e.getMessage());
}
finally
{
System.out.println("Finally Block Of Method One Is Excecuted");
}
}
}
public void method2()
{
synchronized(lock2)
{
try
{
for(int i=0;i<10;i++)
{
System.out.println("Mothod 2:"+i);
Thread.sleep(1000);
}
}
catch(Exception e)
{
System.out.println(e.getMessage());
}
finally
{
System.out.println("Finally Block Excecuted Method2");
}
}
}
public static void main(String args[])
{
ExampleSynchro e=new ExampleSynchro();
e.method1();
e.method2();
}
}