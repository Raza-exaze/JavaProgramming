
class HelloWorld
{
public static void main(String args[])
{
try
{
int a=6;
int b=0;
int z=a/b;
System.out.println(z);
}
catch(Exception e)
{
System.out.println(e.getMessage());
}
//catch(ArithmeticException ex)
//{
//System.out.println(ex.getMessage());
//}
}
}
