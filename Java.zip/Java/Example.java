class AgeNotMatch extends Exception
{
public AgeNotMatch(String str)
{
super(str);
}
}
class Example 
{
public static void ageCheck(int age) throws AgeNotMatch
{
if(age<18)
{
throw new AgeNotMatch("Candidate Is Under Age:"+age);
}
else{
System.out.println("Welcome To New Technology");
}
}
public static void main(String args[])
{
try
{
ageCheck(22);
}
catch(AgeNotMatch anm)
{
System.out.println(anm.getMessage());
}
}
}