import java.util.*;
import java.util.stream.*;

class FilterFunc
{
public static void main(String args[])
{
List<String> al=new ArrayList<>();
al.add("Java");
al.add("Python");
al.add("C#");
al.add("Ruby");

List<String> aa=al.stream().filter(x -> x.startsWith("J")).collect(Collectors.toList());

System.out.println("That Technology Is Available:"+aa);

List<String> as=al.stream().filter(x -> x.endsWith("n")).collect(Collectors.toList());
System.out.println("This Technology Is Available:"+as);
}
}