public class Example1
{
public static void main(String args[]) throws Exception
{
//Runtime.getRuntime().exec("notepad");
Runtime.getRuntime().exec("mspaint");
}
}