class DemoException extends Exception
{
public DemoException(String str)
{
super(str);
}
}
public class DemosException
{
public void Methods() throws DemoException
{
String name="mohamme";
if(name!="mohammed")
{
throw new DemoException("Name Is Not Match Ever Database");
}
else
{
System.out.println("Welcome:" +name);
}
}
public static void main(String args[])
{
try
{
DemosException d=new DemosException();
d.Methods();
}catch(DemoException e)
{
System.out.println(e.getMessage());
}
}
}