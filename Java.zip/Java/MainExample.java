class A
{
public int check(int a)
{
return a;
}
}
class B extends A
{
public int check(int b)
{
return b;
}
}
class MainExample
{
public static void main(String args[])
{
A b=new B();
System.out.println(b.check(22));
}
}