import java.time.*;

class Timer
{
public static void main(String[] args)
{

LocalDate d=LocalDate.now();


System.out.print("Local Date:"+d.getDayOfWeek()+" "+d.getDayOfMonth()+" "+d.getMonth()+" "+d.getYear());
}
}