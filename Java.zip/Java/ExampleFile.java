import java.io.FileInputStream;


class ExampleFile
{
public static void main(String args[]) 
{
try{
FileInputStream fi=new FileInputStream("D:\\Java.txt");
fi.read();
fi.close();
System.out.println("Successful File Readed");
}
catch(Exception e)
{
System.out.println(e.getMessage());
}}
}



