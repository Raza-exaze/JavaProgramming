class Ascii
{
public static void main(String args[])
{
char a='0';
int b=a;

System.out.println(b);

}
}