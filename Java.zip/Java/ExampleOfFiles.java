import java.io.FileWriter;

public class ExampleOfFiles
{
public static void main(String args[])
{
try
{
FileWriter fo=new FileWriter("d:\\text.txt");
fo.write("Hello File Sections");
fo.close();
System.out.println("Successful Created");
}
catch(Exception e)
{
System.out.println("Error Is Throwing:"+e.getMessage());
}
}
}
