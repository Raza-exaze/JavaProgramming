import java.util.Scanner;

class Main
{
static String collname="JNTUH";

public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
System.out.println("Enter Your Roll Number:");
long roll=s.nextLong();
System.out.println("Enter Your Marks:");
double marks=s.nextDouble();

//static Data Values

if(roll==123)
{
if(marks>65)
{
System.out.println("College Name:"+Main.collname);
System.out.println("Student Name: Hateem");
System.out.println("Subject: Maths, Science");
System.out.println("Roll Number:"+roll);
System.out.println("Result: Pass");
}else if(marks<65)
{
System.out.println("College Name:"+Main.collname);
System.out.println("Student Name: Hateem");
System.out.println("Result: Fail");
}
}
else
{
System.out.println("Invalid Roll Number");
}
}
}