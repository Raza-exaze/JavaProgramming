// Online Java Compiler
// Use this editor to write, compile and run your Java code online
import java.util.*;

class Collect 
{
    String name;
    Set<String> subject;
    List<Integer> marks;
    public Collect(String name,Set<String> subject,List<Integer> marks)
    {
        this.name=name;
        this.subject=subject;
        this.marks=marks;
    }
    public static void main(String[] args) 
    {
    Collect h=new Collect("Khan",Set.of("Maths","English","Urdu","Science","Social","Hindi"),List.of(12,22,33,44));
    System.out.println(h.name);
    System.out.println(h.subject);
    System.out.println(h.marks);
    }
}