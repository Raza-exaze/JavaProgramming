import java.util.*;

class ExampleConvertArr
{
    public static void main(String args[])
    {
    //   ArrayList<String> al=new ArrayList<>();
    //   al.add("Java");
    //   al.add("Python");
       
    //   String[] arr=new String[al.size()];
    //   arr=al.toArray(arr);
       
    //   System.out.println(arr);
    //   for(String x:arr)
    //   {
    //       System.out.println(x);
    //   }
    String[] name={"Python","Java","C"};
    List<String> ls=Arrays.asList(name);
    Collections.sort(ls);
    for(String names:ls)
    {
        System.out.println(names);
    }
    }
}