import java.util.*;
import java.util.stream.*;

class ExampleDemos
{
public static void main(String args[])
{
List<Integer> list=new ArrayList<>();

list.add(10);
list.add(20);


System.out.println("ArrayList Call:"+list);

List<Integer> al=list.stream().map(x -> x+x).collect(Collectors.toList());

System.out.println(al);
}
}