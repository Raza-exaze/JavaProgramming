class TestExceptions extends Exception
{
public TestExceptions(String a)
{
super(a);
}
}

///

public class CheckExceptions
{
public void see(int age) throws TestExceptions
{
if(age<18)
{
throw new TestExceptions("Age Is Not Valid For Voting");
}
else
{
System.out.println("Welcome To Voting System Machine");
}
}
public static void main(String args[])
{
try
{
CheckExceptions c=new CheckExceptions();
c.see(22);
}
catch(TestExceptions e)
{
System.out.println(e);
}
}
}

