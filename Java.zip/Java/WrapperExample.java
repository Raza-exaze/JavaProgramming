class WrapperExample {
    public static void main(String[] args) {
        
        int a=20;
        Integer b=Integer.valueOf(a);//AutoBoxing 
        System.out.println("AutoBoxing Example");
        System.out.println(a+" "+b);
        
        Integer c=new Integer(44);
        int d=c.intValue();//UnBoxing
        System.out.println("UnBoxing Example");
        System.out.println(c+" "+d);
        }
}