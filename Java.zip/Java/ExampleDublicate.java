class ExampleDublicate
{
public static void main(String args[])
{
String str="Hello World";
char[] chr=str.toCharArray();  
System.out.println(str);
System.out.println("Dublicate Characters:");

for(int i=0;i<str.length();i++)    
{
for(int j=i+3;j<str.length();j++)  
{
if(chr[i]==chr[j]) 
{
System.out.print(chr[i]+" ");
}
}
}
}
}