import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;


public class Examples
{
public static void main(String args[])
{
try
{
FileReader file=new FileReader("text.txt");
FileWriter file1=new FileWriter("text.txt");
file1.write("Java Is A Programming Language");
file1.close();	
Scanner scan=new Scanner(file);
while(scan.hasNextLine())
{
System.out.println(scan.nextLine());
}
}catch(Exception e)
{
System.out.println(e.getMessage());}
}
}