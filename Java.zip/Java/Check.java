class Check implements Runnable
{
int a,b;
public void run()
{
for(int i=0;i<100;i++)
synchronized(this)
{
a=18;
b=18;
}
System.out.print(a+""+b+"");
}
public static void main(String args[])
{
Check c=new Check();
Thread c1=new Thread(c);
Thread c2=new Thread(c);

c1.start();
c2.start();
}
}