// Online Java Compiler
// Use this editor to write, compile and run your Java code online
import java.util.*;

class ExampleD
{
    Set<String> name;
    List<Integer> age;
    public void toDisplay()
    {
        name=new HashSet<String>();
        name.add("Khan");
        name.add("Mohsin");
        name.add("Munawar");
        name.forEach(x -> System.out.println(x));
        
        age=new ArrayList<Integer>();
        age.add(12);
        age.add(33);
        age.add(44);
        for(Integer a: age)
        {
            if(a>=20)
            {
                System.out.println(a);
            }
        }

    }
    public static void main(String[] args) 
    {
        ExampleD h=new ExampleD();
        h.toDisplay();
    }
}