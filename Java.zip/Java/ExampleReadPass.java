import java.io.*;

class ExampleReadPass
{
public static void main(String args[])
{

Console c=System.console();


System.out.println("Enter Your Password:");

char[] pass=c.readPassword();


String pas=String.valueOf(pass);

System.out.println("Your Password Is:"+pas);
}
}