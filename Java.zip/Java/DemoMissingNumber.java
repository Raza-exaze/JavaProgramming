public class DemoMissingNumber
{
public static void main(String args[])
{
int[] a={1,3,4,5,6,7,8};
int fintNumber=findNumber(a);
System.out.println("Missing Numbers:"+fintNumber);
}
public static int findNumber(int[] a)
{
int n=a.length+1;
int sum=n*(n+1)/2;
int min=0;
for(int i=0;i<a.length;i++)
{
min+=a[i];
}
return sum-min;
}
}