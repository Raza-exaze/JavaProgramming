import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class ExampleBuffered
{
public static void main(String args[]) throws IOException
{
System.out.println("Enter Your Name:");
BufferedReader read=new BufferedReader(new InputStreamReader(System.in));
String name=read.readLine();
System.out.println("Candidate Name:"+name);
}
}