import java.util.*;

class H
{
    public static void main(String[] args) 
    {
        ArrayList<String> al=new ArrayList<>();
        al.add("String");
        al.add(12);
        al.add('a');
        al.add(123.32);
        
        System.out.println(al);
    }
}