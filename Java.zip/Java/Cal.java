import java.time.chrono.*;

class Cal
{
public static void main(String[] args)
{

HijrahDate z=HijrahDate.now();


System.out.println(z);

}
}