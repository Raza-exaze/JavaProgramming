import java.util.*;


 class Student
{
String name;
Set<String> Subject;
List<Integer> Marks;

public Student(String name,Set<String> Subject,List<Integer> Marks)
{
this.name=name;
this.Subject=Subject;
this.Marks=Marks;
}

public static void main(String[] args)
{

Student s=new Student("Amir",Set.of("Urdu","Hindi","English","Science","Social","Maths"),List.of(99,88,99,77,66,78));

System.out.println(s);

System.out.println(s.name);
System.out.println(s.Subject);
System.out.println(s.Marks);

}
}