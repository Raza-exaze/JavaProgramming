import java.util.*;

class ContactDetails
{
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
System.out.println("Enter Your Number:");
Long l=s.nextLong();


System.out.println(l);
}
}