class BoolTest
{
public static void main(String args[])
{
int count=0;
Boolean a1=new Boolean("TRUE");
Boolean a2=new Boolean("true");
Boolean a3=new Boolean("tRuE");
Boolean a4=new Boolean("false");
if(a1==a2)
count=1;
if(al.equals(a2))
count=count+10;
if(a2==a4)
count=count+100;
if(a2.equals(a4))
count=count+1000;
if(a2.equals(a3))
count=count+10000;
System.out.println("count="+count);
}
}