class Unicode
{
public static void main(String[] args)
{

String name="\u00AB Java Programming Language \u00BB";

System.out.println(name);
}
}