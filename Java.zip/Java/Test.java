import java.io.*;

class ExampleSerializ implements Serializable
{
String name=" ";
public ExampleSerializ(String name)
{
this.name=name;
}
}
class Employee extends ExampleSerializ
{
float salary;
public Employee(String name,float salary)
{
super(name);
this.salary=salary;
}
private void writeObject(ObjectOutputStream out) throws IOException
{
throw new NotSerializableException();
}
private void readObject(ObjectInputStream in) throws IOException
{
throw new NotSerializableException();
}
}
public class Test
{
public static void main(String args[]) throws Exception
{
Employee emp=new Employee("Mohammed",20000);

System.out.println("Employee Name:"+emp.name);
System.out.println("Employee Salary:"+emp.salary);

FileOutputStream fos=new FileOutputStream("abc.ser");
ObjectOutputStream os=new ObjectOutputStream(fos);

os.writeObject(emp);

os.close();
fos.close();

System.out.println("Object has been serialized");

FileInputStream f=new FileInputStream("ab.txt");
ObjectInputStream oi=new ObjectInputStream(f);

Employee emp1=(Employee)oi.readObject();
oi.close();
f.close();

System.out.println("Object has been deserialized");

System.out.println("Employee Name:"+emp1.name);
System.out.println("Employee Salary:"+emp1.salary);
}
}